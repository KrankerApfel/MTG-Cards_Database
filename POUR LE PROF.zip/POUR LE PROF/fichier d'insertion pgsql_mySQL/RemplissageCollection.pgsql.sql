INSERT INTO collection(col_nom) VALUES
('Collection Valentin');

Insert INTO possession VALUES
(1, 235, 1, 1),
(1, 520, 1, 1),
(1, 12, 1, 2),
(1, 365, 1, 3),
(1, 412, 1, 1),
(1, 489, 1, 1),
(1, 19, 1, 2);

