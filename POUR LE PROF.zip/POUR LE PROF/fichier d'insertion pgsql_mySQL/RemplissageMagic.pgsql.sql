Insert INTO serie Values
('ODY', 'Odyssey', '2001/09/21', 350),
('TOR', 'Torment', '2002/02/20', 143),
('JUD', 'Judgment', '2002/05/21', 143);

INSERT INTO langue(lang_nom) Values
('anglais');

Insert INTO langue_serie VALUES
(1, 'ODY'),
(1, 'TOR'),
(1, 'JUD');


